import java.util.ArrayList;
import java.util.Collections;
public class NotenVerwaltungEinfach {
    public static void main(String[] args) {
        // 1. Noten eingeben
        ArrayList<Integer> notenListe = new ArrayList<>();
        Collections.addAll(notenListe, 3, 5, 2, 4, 1, 6, 3);

        // 2. Noten anzeigen
        System.out.println("Eingegebene Noten: " + notenListe);

        // 3. Statistiken berechnen
        // Durchschnittsnote berechnen
        int summe = 0;
        for (int note : notenListe) {
            summe += note;
        }
        double durchschnitt = (double) summe / notenListe.size();
        System.out.printf("Durchschnittsnote: %.2f%n", durchschnitt);

        // Beste und schlechteste Note ermitteln
        int besteNote = Collections.max(notenListe);
        int schlechtesteNote = Collections.min(notenListe);
        System.out.println("Beste Note: " + besteNote);
        System.out.println("Schlechteste Note: " + schlechtesteNote);

        // 4. Noten sortieren
        Collections.sort(notenListe);
        System.out.println("Sortierte Noten: " + notenListe);
    }
}
